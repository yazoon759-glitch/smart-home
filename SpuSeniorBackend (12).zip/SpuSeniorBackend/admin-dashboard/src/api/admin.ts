import { apiFetch } from './client';
import type {
  AuthUser,
  Category,
  OverviewResponse,
  Provider,
  User,
  ServiceRequest,
  WalletOptions,
  WalletTransaction
} from '../types';

export const loginRequest = (payload: { email?: string; phone?: string; password: string }) =>
  apiFetch<{ token: string; user: AuthUser }>('/auth/login', { method: 'POST', body: payload });

export const fetchOverview = (token: string) =>
  apiFetch<OverviewResponse>('/api/admin/overview', { token });

export const fetchWalletOptions = (token: string) =>
  apiFetch<WalletOptions>('/api/admin/wallet/options', { token });

export const listCategories = (token: string) =>
  apiFetch<Category[]>('/api/categories', { token });

export const createCategory = (token: string, payload: Partial<Category>) =>
  apiFetch<Category>('/api/admin/categories', { method: 'POST', token, body: payload });

export const updateCategory = (token: string, id: string, payload: Partial<Category>) =>
  apiFetch<Category>(`/api/admin/categories/${id}`, { method: 'PUT', token, body: payload });

export const deleteCategory = (token: string, id: string) =>
  apiFetch<{ success: boolean }>(`/api/admin/categories/${id}`, { method: 'DELETE', token });

export const listProviders = (token: string, query?: { name?: string }) => {
  const params = new URLSearchParams();
  if (query?.name) params.set('name', query.name);
  const suffix = params.toString() ? `?${params.toString()}` : '';
  return apiFetch<Provider[]>(`/api/providers${suffix}`, { token });
};

export const adminListProviders = (
  token: string,
  query?: { serviceCategoryId?: string; includeInactive?: boolean }
) => {
  const params = new URLSearchParams();
  if (query?.serviceCategoryId) params.set('serviceCategoryId', query.serviceCategoryId);
  if (query?.includeInactive !== undefined) {
    params.set('includeInactive', String(query.includeInactive));
  }
  const suffix = params.toString() ? `?${params.toString()}` : '';
  return apiFetch<Provider[]>(`/api/admin/providers${suffix}`, { token });
};

export const adminCreateProvider = (token: string, payload: Record<string, unknown>) =>
  apiFetch<Provider>('/api/admin/providers', { method: 'POST', token, body: payload });

export const adminUpdateProvider = (token: string, id: string, payload: Record<string, unknown>) =>
  apiFetch<Provider>(`/api/admin/providers/${id}`, { method: 'PUT', token, body: payload });

export const adminDeleteProvider = (token: string, id: string) =>
  apiFetch<{ success: boolean }>(`/api/admin/providers/${id}`, { method: 'DELETE', token });

export const adminListUsers = (token: string) =>
  apiFetch<User[]>('/api/admin/users', { token });

export const adminCreateUser = (
  token: string,
  payload: Partial<User> & { password: string }
) => apiFetch<User>('/api/admin/users', { method: 'POST', token, body: payload });

export const adminUpdateUser = (
  token: string,
  id: string,
  payload: Partial<User> & { password?: string }
) => apiFetch<User>(`/api/admin/users/${id}`, { method: 'PUT', token, body: payload });

export const adminDeleteUser = (token: string, id: string) =>
  apiFetch<{ success: boolean }>(`/api/admin/users/${id}`, { method: 'DELETE', token });

export const listRequests = (token: string, query?: { status?: string; limit?: number }) => {
  const params = new URLSearchParams();
  if (query?.status) params.set('status', query.status);
  if (query?.limit) params.set('limit', String(query.limit));
  const suffix = params.toString() ? `?${params.toString()}` : '';
  return apiFetch<ServiceRequest[]>(`/api/admin/requests${suffix}`, { token });
};

export const listTransactions = (token: string, query?: { status?: string; limit?: number }) => {
  const params = new URLSearchParams();
  if (query?.status) params.set('status', query.status);
  if (query?.limit) params.set('limit', String(query.limit));
  const suffix = params.toString() ? `?${params.toString()}` : '';
  return apiFetch<WalletTransaction[]>(`/api/admin/transactions${suffix}`, { token });
};

export const walletTopUpUser = (token: string, payload: { userId: string; amount: number }) =>
  apiFetch('/api/admin/wallet/topup-user', { method: 'POST', token, body: payload });

export const walletTopUpProvider = (token: string, payload: { providerId: string; amount: number }) =>
  apiFetch('/api/admin/wallet/topup-provider', { method: 'POST', token, body: payload });

export const walletProviderEarning = (
  token: string,
  payload: { providerId: string; serviceRequestId: string; amount: number }
) => apiFetch('/api/admin/wallet/provider-earning', { method: 'POST', token, body: payload });

export const walletApproveCashIn = (token: string, transactionId: string) =>
  apiFetch(`/api/admin/wallet/cash-in/${transactionId}/approve`, { method: 'POST', token });

export const walletRejectCashIn = (token: string, transactionId: string) =>
  apiFetch(`/api/admin/wallet/cash-in/${transactionId}/reject`, { method: 'POST', token });

export const walletApproveWithdraw = (token: string, transactionId: string) =>
  apiFetch(`/api/admin/wallet/withdraw/${transactionId}/approve`, { method: 'POST', token });

export const walletRejectWithdraw = (token: string, transactionId: string) =>
  apiFetch(`/api/admin/wallet/withdraw/${transactionId}/reject`, { method: 'POST', token });
