export type AuthUser = {
  id: string;
  email: string;
  role: string;
  firstName?: string;
  lastName?: string;
};

export type UserRef = {
  _id: string;
  firstName?: string;
  lastName?: string;
  email?: string;
  phone?: string;
  isActive?: boolean;
};

export type User = {
  _id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  role: string;
  isActive: boolean;
  walletBalance?: number;
  createdAt?: string;
};

export type Category = {
  _id: string;
  name: string;
  description?: string;
  basePrice: number;
  icon?: string | null;
  isActive: boolean;
};

export type Provider = {
  _id: string;
  userId?: UserRef;
  serviceCategoryId?: { _id: string; name: string };
  walletBalance?: number;
  averageRating?: number;
  totalCompletedJobs?: number;
  fixedLatitude?: number;
  fixedLongitude?: number;
  addressLine?: string;
  isActive?: boolean;
  location?: { coordinates?: number[] };
};

export type ServiceRequest = {
  _id: string;
  status: string;
  paymentStatus?: string;
  paymentMethod?: string;
  price?: number;
  requestedDateTime?: string;
  userId?: UserRef;
  providerId?: { _id: string; userId?: UserRef };
  serviceCategoryId?: { _id: string; name: string };
  userLocationId?: Record<string, unknown>;
  createdAt?: string;
};

export type WalletTransaction = {
  _id: string;
  type: string;
  status: string;
  amount: number;
  userId?: UserRef;
  providerId?: { _id: string; userId?: UserRef };
  relatedServiceRequestId?: { _id: string; status?: string; paymentStatus?: string };
  createdAt?: string;
};

export type OverviewResponse = {
  counts: {
    users: number;
    providers: number;
    categories: number;
    pendingTransactions: number;
  };
  requestsByStatus: Record<string, number>;
  recent: {
    requests: ServiceRequest[];
    transactions: WalletTransaction[];
  };
};

export type WalletOptions = {
  users: UserRef[];
  providers: Provider[];
  serviceRequests: ServiceRequest[];
  pendingTransactions: WalletTransaction[];
};
