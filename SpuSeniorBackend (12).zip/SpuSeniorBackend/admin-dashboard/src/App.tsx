import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import Layout from './components/Layout';
import { useAuth } from './context/AuthContext';
import LoginPage from './pages/Login';
import DashboardPage from './pages/Dashboard';
import CategoriesPage from './pages/Categories';
import UsersPage from './pages/Users';
import ProvidersPage from './pages/Providers';
import RequestsPage from './pages/Requests';
import WalletPage from './pages/Wallet';

const Protected = ({ children }: { children: JSX.Element }) => {
  const { isAuthed } = useAuth();
  const location = useLocation();
  if (!isAuthed) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }
  return children;
};

const App = () => (
  <Routes>
    <Route path="/login" element={<LoginPage />} />
    <Route
      path="/"
      element={
        <Protected>
          <Layout />
        </Protected>
      }
    >
      <Route index element={<DashboardPage />} />
      <Route path="users" element={<UsersPage />} />
      <Route path="categories" element={<CategoriesPage />} />
      <Route path="providers" element={<ProvidersPage />} />
      <Route path="requests" element={<RequestsPage />} />
      <Route path="wallet" element={<WalletPage />} />
    </Route>
    <Route path="*" element={<Navigate to="/" replace />} />
  </Routes>
);

export default App;
