import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const navItems = [
  { to: '/', label: 'Overview', exact: true },
  { to: '/users', label: 'Users' },
  { to: '/categories', label: 'Categories' },
  { to: '/providers', label: 'Providers' },
  { to: '/requests', label: 'Requests' },
  { to: '/wallet', label: 'Wallet' }
];

const Layout = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">Ops Control</div>
        <nav>
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.exact}
              className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
      </aside>
      <div className="content">
        <header className="topbar">
          <div className="greeting">
            <h1>Admin Desk</h1>
            <small>
              Signed in as {user?.firstName || user?.email} ({user?.role})
            </small>
          </div>
          <button className="btn secondary" onClick={handleLogout}>
            Sign out
          </button>
        </header>
        <div className="content-body">
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default Layout;
