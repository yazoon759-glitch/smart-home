import { type FormEvent, useEffect, useMemo, useState } from 'react';
import {
  fetchWalletOptions,
  walletApproveCashIn,
  walletApproveWithdraw,
  walletProviderEarning,
  walletRejectCashIn,
  walletRejectWithdraw,
  walletTopUpProvider,
  walletTopUpUser
} from '../api/admin';
import { useAuth } from '../context/AuthContext';
import type { WalletOptions, WalletTransaction } from '../types';
import { formatDate, fullName } from '../utils/format';

const WalletPage = () => {
  const { token } = useAuth();
  const [options, setOptions] = useState<WalletOptions | null>(null);
  const [pending, setPending] = useState<WalletTransaction[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');

  const [userTopUp, setUserTopUp] = useState({ userId: '', amount: '' });
  const [providerTopUp, setProviderTopUp] = useState({ providerId: '', amount: '' });
  const [providerEarning, setProviderEarning] = useState({
    providerId: '',
    serviceRequestId: '',
    amount: ''
  });
  const [cashInTx, setCashInTx] = useState('');
  const [withdrawTx, setWithdrawTx] = useState('');

  const loadOptions = async () => {
    if (!token) return;
    setLoading(true);
    setError('');
    try {
      const data = await fetchWalletOptions(token);
      setOptions(data);
      setPending(data.pendingTransactions);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load wallet data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadOptions();
  }, [token]);

  const pendingCashIns = useMemo(
    () => pending.filter((tx) => tx.type === 'CASH_IN_REQUEST'),
    [pending]
  );
  const pendingWithdrawals = useMemo(
    () => pending.filter((tx) => tx.type === 'WITHDRAWAL_REQUEST'),
    [pending]
  );
  const earningRequests = useMemo(() => {
    if (!providerEarning.providerId) return options?.serviceRequests ?? [];
    return (options?.serviceRequests ?? []).filter(
      (req) => !req.providerId || req.providerId._id === providerEarning.providerId
    );
  }, [options?.serviceRequests, providerEarning.providerId]);

  const handleUserTopUp = async (e: FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setMessage('');
    setError('');
    const amount = Number(userTopUp.amount);
    if (!userTopUp.userId || Number.isNaN(amount) || amount <= 0) {
      setError('Select a user and enter a positive amount.');
      return;
    }
    try {
      await walletTopUpUser(token, { userId: userTopUp.userId, amount });
      setMessage('User wallet topped up.');
      setUserTopUp({ userId: '', amount: '' });
      await loadOptions();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Top-up failed');
    }
  };

  const handleProviderTopUp = async (e: FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setMessage('');
    setError('');
    const amount = Number(providerTopUp.amount);
    if (!providerTopUp.providerId || Number.isNaN(amount) || amount <= 0) {
      setError('Select a provider and enter a positive amount.');
      return;
    }
    try {
      await walletTopUpProvider(token, {
        providerId: providerTopUp.providerId,
        amount
      });
      setMessage('Provider wallet adjusted.');
      setProviderTopUp({ providerId: '', amount: '' });
      await loadOptions();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Adjustment failed');
    }
  };

  const handleProviderEarning = async (e: FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setMessage('');
    setError('');
    const amount = Number(providerEarning.amount);
    if (
      !providerEarning.providerId ||
      !providerEarning.serviceRequestId ||
      Number.isNaN(amount) ||
      amount <= 0
    ) {
      setError('Provider, request, and positive amount are required.');
      return;
    }
    try {
      await walletProviderEarning(token, {
        providerId: providerEarning.providerId,
        serviceRequestId: providerEarning.serviceRequestId,
        amount
      });
      setMessage('Provider earning recorded.');
      setProviderEarning({ providerId: '', serviceRequestId: '', amount: '' });
      await loadOptions();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Operation failed');
    }
  };

  const handleCashIn = async (action: 'approve' | 'reject') => {
    if (!token) return;
    setMessage('');
    setError('');
    if (!cashInTx) {
      setError('Select a pending cash-in transaction.');
      return;
    }
    try {
      if (action === 'approve') {
        await walletApproveCashIn(token, cashInTx);
        setMessage('Cash-in approved.');
      } else {
        await walletRejectCashIn(token, cashInTx);
        setMessage('Cash-in rejected.');
      }
      setCashInTx('');
      await loadOptions();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Cash-in action failed');
    }
  };

  const handleWithdraw = async (action: 'approve' | 'reject') => {
    if (!token) return;
    setMessage('');
    setError('');
    if (!withdrawTx) {
      setError('Select a pending withdrawal transaction.');
      return;
    }
    try {
      if (action === 'approve') {
        await walletApproveWithdraw(token, withdrawTx);
        setMessage('Withdrawal approved.');
      } else {
        await walletRejectWithdraw(token, withdrawTx);
        setMessage('Withdrawal rejected.');
      }
      setWithdrawTx('');
      await loadOptions();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Withdraw action failed');
    }
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 12 }}>
        <button className="btn secondary" type="button" onClick={() => void loadOptions()}>
          Refresh lists
        </button>
      </div>

      <div className="card-grid">
        <div className="card">
          <div className="section-title">
            <h3>Top-up user wallet</h3>
            <small>Pick a user instead of typing an id</small>
          </div>
          <form onSubmit={handleUserTopUp}>
            <label htmlFor="userId">User</label>
            <select
              id="userId"
              value={userTopUp.userId}
              onChange={(e) => setUserTopUp((prev) => ({ ...prev, userId: e.target.value }))}
              disabled={!options?.users?.length}
            >
              <option value="">Select user</option>
              {options?.users.map((u) => (
                <option key={u._id} value={u._id}>
                  {fullName(u)} {u.email ? `(${u.email})` : ''}
                </option>
              ))}
            </select>
            <label htmlFor="userAmount">Amount</label>
            <input
              id="userAmount"
              type="number"
              min="1"
              value={userTopUp.amount}
              onChange={(e) => setUserTopUp((prev) => ({ ...prev, amount: e.target.value }))}
            />
            <button className="btn" type="submit" style={{ marginTop: 10 }}>
              Top up
            </button>
          </form>
        </div>

        <div className="card">
          <div className="section-title">
            <h3>Adjust provider wallet</h3>
            <small>Choose from the provider list</small>
          </div>
          <form onSubmit={handleProviderTopUp}>
            <label htmlFor="providerId">Provider</label>
            <select
              id="providerId"
              value={providerTopUp.providerId}
              onChange={(e) =>
                setProviderTopUp((prev) => ({ ...prev, providerId: e.target.value }))
              }
              disabled={!options?.providers?.length}
            >
              <option value="">Select provider</option>
              {options?.providers.map((p) => (
                <option key={p._id} value={p._id}>
                  {fullName(p.userId)} {p.serviceCategoryId?.name ? `- ${p.serviceCategoryId.name}` : ''}
                </option>
              ))}
            </select>
            <label htmlFor="providerAmount">Amount</label>
            <input
              id="providerAmount"
              type="number"
              min="1"
              value={providerTopUp.amount}
              onChange={(e) => setProviderTopUp((prev) => ({ ...prev, amount: e.target.value }))}
            />
            <button className="btn" type="submit" style={{ marginTop: 10 }}>
              Apply
            </button>
          </form>
        </div>

        <div className="card">
          <div className="section-title">
            <h3>Record provider earning</h3>
            <small>Link to a request and provider</small>
          </div>
          <form onSubmit={handleProviderEarning}>
            <label htmlFor="earningProviderId">Provider</label>
            <select
              id="earningProviderId"
              value={providerEarning.providerId}
              onChange={(e) =>
                setProviderEarning((prev) => ({ ...prev, providerId: e.target.value }))
              }
              disabled={!options?.providers?.length}
            >
              <option value="">Select provider</option>
              {options?.providers.map((p) => (
                <option key={p._id} value={p._id}>
                  {fullName(p.userId)} {p.serviceCategoryId?.name ? `- ${p.serviceCategoryId.name}` : ''}
                </option>
              ))}
            </select>
            <label htmlFor="serviceRequestId">Service request</label>
            <select
              id="serviceRequestId"
              value={providerEarning.serviceRequestId}
              onChange={(e) =>
                setProviderEarning((prev) => ({ ...prev, serviceRequestId: e.target.value }))
              }
              disabled={!options?.serviceRequests?.length}
            >
              <option value="">Select request</option>
              {earningRequests.map((req) => (
                <option key={req._id} value={req._id}>
                  {req.serviceCategoryId?.name || 'Service'} - {req.status} - {fullName(req.userId)}{' '}
                  {req.providerId ? `-> ${fullName(req.providerId.userId)}` : '(unassigned)'}
                </option>
              ))}
            </select>
            <label htmlFor="earningAmount">Amount</label>
            <input
              id="earningAmount"
              type="number"
              min="1"
              value={providerEarning.amount}
              onChange={(e) =>
                setProviderEarning((prev) => ({ ...prev, amount: e.target.value }))
              }
            />
            <button className="btn" type="submit" style={{ marginTop: 10 }}>
              Record earning
            </button>
          </form>
        </div>
      </div>

      <div className="card-grid">
        <div className="card">
          <div className="section-title">
            <h3>Cash-in approvals</h3>
            <small>Pending requests only</small>
          </div>
          <select value={cashInTx} onChange={(e) => setCashInTx(e.target.value)}>
            <option value="">Select pending cash-in</option>
            {pendingCashIns.map((tx) => (
              <option key={tx._id} value={tx._id}>
                {fullName(tx.userId)} - ${tx.amount.toFixed(2)} ({tx._id})
              </option>
            ))}
          </select>
          <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
            <button className="btn" type="button" onClick={() => void handleCashIn('approve')}>
              Approve
            </button>
            <button className="btn danger" type="button" onClick={() => void handleCashIn('reject')}>
              Reject
            </button>
          </div>
        </div>

        <div className="card">
          <div className="section-title">
            <h3>Withdrawal approvals</h3>
            <small>Pending withdrawals</small>
          </div>
          <select value={withdrawTx} onChange={(e) => setWithdrawTx(e.target.value)}>
            <option value="">Select pending withdrawal</option>
            {pendingWithdrawals.map((tx) => (
              <option key={tx._id} value={tx._id}>
                {fullName(tx.providerId?.userId)} - ${tx.amount.toFixed(2)} ({tx._id})
              </option>
            ))}
          </select>
          <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
            <button className="btn" type="button" onClick={() => void handleWithdraw('approve')}>
              Approve
            </button>
            <button
              className="btn danger"
              type="button"
              onClick={() => void handleWithdraw('reject')}
            >
              Reject
            </button>
          </div>
        </div>
      </div>

      {error ? <div className="error">{error}</div> : null}
      {message ? <div className="success">{message}</div> : null}

      <div className="panel">
        <div className="section-title">
          <h2>Pending transactions</h2>
          <small>Acts as the source for the dropdowns above</small>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table className="table">
            <thead>
              <tr>
                <th>Id</th>
                <th>Type</th>
                <th>User</th>
                <th>Provider</th>
                <th>Amount</th>
                <th>Created</th>
              </tr>
            </thead>
            <tbody>
              {pending.length ? (
                pending.map((tx) => (
                  <tr key={tx._id}>
                    <td>
                      <code>{tx._id}</code>
                    </td>
                    <td>{tx.type}</td>
                    <td>{fullName(tx.userId)}</td>
                    <td>{fullName(tx.providerId?.userId)}</td>
                    <td>${tx.amount.toFixed(2)}</td>
                    <td>{formatDate(tx.createdAt)}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6}>No pending items.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {loading ? <div className="helper">Loading...</div> : null}
      <div className="helper">
        Tip: seed the admin account from the backend to log in, then refresh lists after new wallet
        activity comes in from users or providers.
      </div>
    </div>
  );
};

export default WalletPage;
