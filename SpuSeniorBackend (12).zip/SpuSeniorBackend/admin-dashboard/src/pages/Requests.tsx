import { useEffect, useState } from 'react';
import { listRequests } from '../api/admin';
import { useAuth } from '../context/AuthContext';
import type { ServiceRequest } from '../types';
import { formatDate, fullName } from '../utils/format';

const statuses = ['ALL', 'PENDING', 'ACCEPTED', 'IN_PROGRESS', 'COMPLETED', 'REJECTED', 'CANCELED'];

const RequestsPage = () => {
  const { token } = useAuth();
  const [items, setItems] = useState<ServiceRequest[]>([]);
  const [status, setStatus] = useState<string>('ALL');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const load = async () => {
    if (!token) return;
    setLoading(true);
    setError('');
    try {
      const data = await listRequests(token, status === 'ALL' ? undefined : { status });
      setItems(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load requests');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, [status, token]);

  return (
    <div>
      <div className="panel">
        <div className="section-title">
          <h2>Service requests</h2>
          <small>Filter by status</small>
        </div>
        <select value={status} onChange={(e) => setStatus(e.target.value)}>
          {statuses.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
        {error ? <div className="error">{error}</div> : null}
      </div>

      <div className="panel">
        <div className="section-title">
          <h2>Latest requests</h2>
          <small>{items.length} rows</small>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table className="table">
            <thead>
              <tr>
                <th>Service</th>
                <th>User</th>
                <th>Provider</th>
                <th>Status</th>
                <th>Payment</th>
                <th>Created</th>
              </tr>
            </thead>
            <tbody>
              {items.length ? (
                items.map((req) => (
                  <tr key={req._id}>
                    <td>
                      <div>{req.serviceCategoryId?.name || '—'}</div>
                      <small>{req.paymentMethod || ''}</small>
                    </td>
                    <td>{fullName(req.userId)}</td>
                    <td>{fullName(req.providerId?.userId)}</td>
                    <td>
                      <span className={`status-pill status-${req.status}`}>{req.status}</span>
                    </td>
                    <td>
                      <div>${(req.price ?? 0).toFixed(2)}</div>
                      <small>{req.paymentStatus}</small>
                    </td>
                    <td>{formatDate(req.createdAt)}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6}>No requests found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {loading ? <div className="helper">Loading…</div> : null}
    </div>
  );
};

export default RequestsPage;
