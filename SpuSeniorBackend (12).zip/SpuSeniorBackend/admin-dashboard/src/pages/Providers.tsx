import { type FormEvent, useEffect, useMemo, useState } from 'react';
import { MapContainer, Marker, TileLayer, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import {
  adminCreateProvider,
  adminDeleteProvider,
  adminListProviders,
  adminUpdateProvider,
  listCategories
} from '../api/admin';
import { useAuth } from '../context/AuthContext';
import type { Category, Provider } from '../types';
import { fullName } from '../utils/format';

const markerIcon = new URL('leaflet/dist/images/marker-icon.png', import.meta.url).toString();
const markerIcon2x = new URL('leaflet/dist/images/marker-icon-2x.png', import.meta.url).toString();
const markerShadow = new URL('leaflet/dist/images/marker-shadow.png', import.meta.url).toString();
L.Icon.Default.mergeOptions({
  iconUrl: markerIcon,
  iconRetinaUrl: markerIcon2x,
  shadowUrl: markerShadow
});

type ProviderForm = {
  providerId?: string;
  userId: string;
  serviceCategoryId: string;
  addressLine: string;
  fixedLatitude: string;
  fixedLongitude: string;
  isActive: boolean;
  newUser: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    password: string;
  };
};

const emptyForm: ProviderForm = {
  userId: '',
  serviceCategoryId: '',
  addressLine: '',
  fixedLatitude: '',
  fixedLongitude: '',
  isActive: true,
  newUser: {
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    password: ''
  }
};

const parseCoord = (value: string) => {
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
};

const MapPicker = ({ latitude, longitude, onPick }: { latitude: string; longitude: string; onPick: (lat: number, lng: number) => void }) => {
  const latNum = parseCoord(latitude);
  const lngNum = parseCoord(longitude);
  const hasPoint = latNum !== null && lngNum !== null;
  const center: [number, number] = hasPoint ? [latNum, lngNum] : [24.7136, 46.6753];

  const ClickCatcher = () => {
    useMapEvents({
      click(e) {
        onPick(e.latlng.lat, e.latlng.lng);
      }
    });
    return null;
  };

  return (
    <MapContainer center={center} zoom={11} scrollWheelZoom style={{ height: 320 }}>
      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a>'
      />
      {hasPoint ? <Marker position={[latNum, lngNum]} /> : null}
      <ClickCatcher />
    </MapContainer>
  );
};

const ProvidersPage = () => {
  const { token } = useAuth();
  const [providers, setProviders] = useState<Provider[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [form, setForm] = useState<ProviderForm>({ ...emptyForm });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [search, setSearch] = useState('');

  const load = async () => {
    if (!token) return;
    setLoading(true);
    setError('');
    try {
      const [provData, catData] = await Promise.all([
        adminListProviders(token, { includeInactive: true }),
        listCategories(token)
      ]);
      setProviders(provData);
      setCategories(catData);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load providers');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, [token]);

  const filteredProviders = useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return providers;
    return providers.filter((p) => {
      const name = fullName(p.userId).toLowerCase();
      return name.includes(term) || (p.userId?.email || '').toLowerCase().includes(term);
    });
  }, [providers, search]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setError('');
    setSuccess('');
    if (!form.serviceCategoryId) {
      setError('Category is required.');
      return;
    }
    const payload: Record<string, unknown> = {
      serviceCategoryId: form.serviceCategoryId,
      addressLine: form.addressLine.trim(),
      isActive: form.isActive
    };
    if (form.fixedLatitude && form.fixedLongitude) {
      payload.fixedLatitude = Number(form.fixedLatitude);
      payload.fixedLongitude = Number(form.fixedLongitude);
    }
    const hasNewUser =
      form.newUser.firstName.trim() &&
      form.newUser.lastName.trim() &&
      form.newUser.email.trim() &&
      form.newUser.phone.trim() &&
      form.newUser.password.trim();
    if (!editingId) {
      if (form.userId.trim()) {
        payload.userId = form.userId.trim();
      } else if (hasNewUser) {
        payload.user = {
          firstName: form.newUser.firstName.trim(),
          lastName: form.newUser.lastName.trim(),
          email: form.newUser.email.trim(),
          phone: form.newUser.phone.trim(),
          password: form.newUser.password.trim()
        };
      } else {
        setError('Provide an existing user ID or fill new user details.');
        return;
      }
    }
    setLoading(true);
    try {
      if (editingId) {
        await adminUpdateProvider(token, editingId, payload);
        setSuccess('Provider updated.');
      } else {
        await adminCreateProvider(token, payload);
        setSuccess('Provider created.');
      }
      setForm({ ...emptyForm });
      setEditingId(null);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Save failed');
    } finally {
      setLoading(false);
    }
  };

  const startEdit = (prov: Provider) => {
    setEditingId(prov._id);
    setForm({
      userId: prov.userId?._id || '',
      serviceCategoryId: prov.serviceCategoryId?._id || '',
      addressLine: prov.addressLine || '',
      fixedLatitude:
        typeof prov.fixedLatitude === 'number' ? String(prov.fixedLatitude) : prov.location?.coordinates?.[1]?.toString() || '',
      fixedLongitude:
        typeof prov.fixedLongitude === 'number' ? String(prov.fixedLongitude) : prov.location?.coordinates?.[0]?.toString() || '',
      isActive: prov.isActive !== false,
      newUser: { ...emptyForm.newUser }
    });
  };

  const handleDelete = async (id: string) => {
    if (!token) return;
    if (!window.confirm('Deactivate this provider?')) return;
    setError('');
    setSuccess('');
    try {
      await adminDeleteProvider(token, id);
      setSuccess('Provider deactivated.');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Delete failed');
    }
  };

  return (
    <div>
      <div className="panel">
        <div className="section-title">
          <h2>{editingId ? 'Edit provider' : 'Create provider'}</h2>
          <small>Admin can attach existing users or create new ones</small>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="form-row">
            <div>
              <label htmlFor="serviceCategoryId">Category</label>
              <select
                id="serviceCategoryId"
                value={form.serviceCategoryId}
                onChange={(e) => setForm((prev) => ({ ...prev, serviceCategoryId: e.target.value }))}
                required
              >
                <option value="">Select category</option>
                {categories.map((c) => (
                  <option key={c._id} value={c._id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="userId">Existing user ID</label>
              <input
                id="userId"
                value={form.userId}
                onChange={(e) => setForm((prev) => ({ ...prev, userId: e.target.value }))}
                placeholder="Leave blank to create new user"
                disabled={Boolean(editingId)}
              />
            </div>
            <div>
              <label htmlFor="addressLine">Address</label>
              <input
                id="addressLine"
                value={form.addressLine}
                onChange={(e) => setForm((prev) => ({ ...prev, addressLine: e.target.value }))}
              />
            </div>
            <div>
              <label htmlFor="fixedLatitude">Latitude</label>
              <input
                id="fixedLatitude"
                value={form.fixedLatitude}
                onChange={(e) => setForm((prev) => ({ ...prev, fixedLatitude: e.target.value }))}
              />
            </div>
            <div>
              <label htmlFor="fixedLongitude">Longitude</label>
              <input
                id="fixedLongitude"
                value={form.fixedLongitude}
                onChange={(e) => setForm((prev) => ({ ...prev, fixedLongitude: e.target.value }))}
              />
            </div>
            <div>
              <label htmlFor="isActive">Status</label>
              <select
                id="isActive"
                value={form.isActive ? 'true' : 'false'}
                onChange={(e) => setForm((prev) => ({ ...prev, isActive: e.target.value === 'true' }))}
              >
                <option value="true">Active</option>
                <option value="false">Inactive</option>
              </select>
            </div>
          </div>
          <div className="card map-card" style={{ marginTop: 12 }}>
            <div className="section-title">
              <h3>Pin provider location</h3>
              <small>Click the map to set latitude/longitude</small>
            </div>
            <MapPicker
              latitude={form.fixedLatitude}
              longitude={form.fixedLongitude}
              onPick={(lat, lng) =>
                setForm((prev) => ({
                  ...prev,
                  fixedLatitude: lat.toFixed(6),
                  fixedLongitude: lng.toFixed(6)
                }))
              }
            />
            <div className="helper">
              Coordinates are stored on the profile and used for distance-based matching.
            </div>
          </div>
          {!editingId ? (
            <>
              <div className="section-title" style={{ marginTop: 12 }}>
                <h3>New user details (optional)</h3>
                <small>Fill these if no existing user ID</small>
              </div>
              <div className="form-row">
                <div>
                  <label htmlFor="nuFirst">First name</label>
                  <input
                    id="nuFirst"
                    value={form.newUser.firstName}
                    onChange={(e) =>
                      setForm((prev) => ({ ...prev, newUser: { ...prev.newUser, firstName: e.target.value } }))
                    }
                  />
                </div>
                <div>
                  <label htmlFor="nuLast">Last name</label>
                  <input
                    id="nuLast"
                    value={form.newUser.lastName}
                    onChange={(e) =>
                      setForm((prev) => ({ ...prev, newUser: { ...prev.newUser, lastName: e.target.value } }))
                    }
                  />
                </div>
                <div>
                  <label htmlFor="nuEmail">Email</label>
                  <input
                    id="nuEmail"
                    type="email"
                    value={form.newUser.email}
                    onChange={(e) =>
                      setForm((prev) => ({ ...prev, newUser: { ...prev.newUser, email: e.target.value } }))
                    }
                  />
                </div>
                <div>
                  <label htmlFor="nuPhone">Phone</label>
                  <input
                    id="nuPhone"
                    value={form.newUser.phone}
                    onChange={(e) =>
                      setForm((prev) => ({ ...prev, newUser: { ...prev.newUser, phone: e.target.value } }))
                    }
                  />
                </div>
                <div>
                  <label htmlFor="nuPass">Password</label>
                  <input
                    id="nuPass"
                    type="password"
                    value={form.newUser.password}
                    onChange={(e) =>
                      setForm((prev) => ({ ...prev, newUser: { ...prev.newUser, password: e.target.value } }))
                    }
                  />
                </div>
              </div>
            </>
          ) : null}
          {error ? <div className="error">{error}</div> : null}
          {success ? <div className="success">{success}</div> : null}
          <div style={{ display: 'flex', gap: 12, marginTop: 12 }}>
            <button className="btn" type="submit" disabled={loading}>
              {editingId ? 'Update provider' : 'Create provider'}
            </button>
            {editingId ? (
              <button
                type="button"
                className="btn secondary"
                onClick={() => {
                  setForm({ ...emptyForm });
                  setEditingId(null);
                }}
              >
                Cancel edit
              </button>
            ) : null}
          </div>
        </form>
      </div>

      <div className="panel">
        <div className="section-title">
          <h2>Providers</h2>
          <small>{providers.length} records</small>
        </div>
        <div style={{ display: 'flex', gap: 12, marginBottom: 12 }}>
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Filter by name or email"
          />
          <button className="btn secondary" type="button" onClick={() => void load()}>
            Refresh
          </button>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Contact</th>
                <th>Category</th>
                <th>Wallet</th>
                <th>Status</th>
                <th style={{ width: 170 }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredProviders.length ? (
                filteredProviders.map((p) => (
                  <tr key={p._id}>
                    <td>{fullName(p.userId)}</td>
                    <td>
                      <div>{p.userId?.email || '??'}</div>
                      <small>{p.userId?.phone || ''}</small>
                    </td>
                    <td>{p.serviceCategoryId?.name || '??'}</td>
                    <td>${(p.walletBalance ?? 0).toFixed(2)}</td>
                    <td>
                      <span className={`status-pill status-${p.isActive === false ? 'REJECTED' : 'APPROVED'}`}>
                        {p.isActive === false ? 'Inactive' : 'Active'}
                      </span>
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: 8 }}>
                        <button className="btn secondary" onClick={() => startEdit(p)}>
                          Edit
                        </button>
                        <button className="btn danger" onClick={() => void handleDelete(p._id)}>
                          Deactivate
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6}>No providers found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {loading ? <div className="helper">Working...</div> : null}
    </div>
  );
};

export default ProvidersPage;
