import { useEffect, useMemo, useState } from 'react';
import { fetchOverview } from '../api/admin';
import { useAuth } from '../context/AuthContext';
import type { OverviewResponse } from '../types';
import { formatDate, fullName } from '../utils/format';

const DashboardPage = () => {
  const { token } = useAuth();
  const [overview, setOverview] = useState<OverviewResponse | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!token) return;
    const load = async () => {
      setLoading(true);
      setError('');
      try {
        const data = await fetchOverview(token);
        setOverview(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load overview');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [token]);

  const statusBadges = useMemo(() => {
    if (!overview) return [];
    return Object.entries(overview.requestsByStatus || {}).map(([key, count]) => ({
      key,
      count
    }));
  }, [overview]);

  return (
    <div>
      <div className="card-grid">
        <div className="card">
          <h3>Total users</h3>
          <div className="stat">{overview?.counts.users ?? '—'}</div>
        </div>
        <div className="card">
          <h3>Providers</h3>
          <div className="stat">{overview?.counts.providers ?? '—'}</div>
        </div>
        <div className="card">
          <h3>Categories</h3>
          <div className="stat">{overview?.counts.categories ?? '—'}</div>
        </div>
        <div className="card">
          <h3>Pending wallet actions</h3>
          <div className="stat">{overview?.counts.pendingTransactions ?? '—'}</div>
        </div>
      </div>

      <div className="panel">
        <div className="section-title">
          <h2>Request health</h2>
          <small>Status distribution</small>
        </div>
        <ul className="list-inline">
          {statusBadges.length
            ? statusBadges.map((item) => (
                <li key={item.key} className={`status-pill status-${item.key}`}>
                  {item.key}: {item.count}
                </li>
              ))
            : 'No requests yet.'}
        </ul>
      </div>

      <div className="panel">
        <div className="section-title">
          <h2>Recent requests</h2>
          <small>Latest 5 across the platform</small>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table className="table">
            <thead>
              <tr>
                <th>Service</th>
                <th>User</th>
                <th>Provider</th>
                <th>Status</th>
                <th>Requested</th>
              </tr>
            </thead>
            <tbody>
              {overview?.recent.requests.length ? (
                overview.recent.requests.map((req) => (
                  <tr key={req._id}>
                    <td>{req.serviceCategoryId?.name || '—'}</td>
                    <td>{fullName(req.userId)}</td>
                    <td>{fullName(req.providerId?.userId)}</td>
                    <td>
                      <span className={`status-pill status-${req.status}`}>{req.status}</span>
                    </td>
                    <td>{formatDate(req.createdAt)}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5}>No data yet.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="panel">
        <div className="section-title">
          <h2>Recent wallet transactions</h2>
          <small>Latest 5</small>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table className="table">
            <thead>
              <tr>
                <th>Type</th>
                <th>User</th>
                <th>Provider</th>
                <th>Status</th>
                <th>Amount</th>
                <th>Created</th>
              </tr>
            </thead>
            <tbody>
              {overview?.recent.transactions.length ? (
                overview.recent.transactions.map((tx) => (
                  <tr key={tx._id}>
                    <td>{tx.type}</td>
                    <td>{fullName(tx.userId)}</td>
                    <td>{fullName(tx.providerId?.userId)}</td>
                    <td>
                      <span className={`status-pill status-${tx.status}`}>{tx.status}</span>
                    </td>
                    <td>${tx.amount.toFixed(2)}</td>
                    <td>{formatDate(tx.createdAt)}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6}>No data yet.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {loading ? <div className="helper">Loading...</div> : null}
      {error ? <div className="error">{error}</div> : null}
    </div>
  );
};

export default DashboardPage;
