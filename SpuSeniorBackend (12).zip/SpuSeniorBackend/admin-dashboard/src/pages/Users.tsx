import { type FormEvent, useEffect, useState } from 'react';
import {
  adminCreateUser,
  adminDeleteUser,
  adminListUsers,
  adminUpdateUser
} from '../api/admin';
import { useAuth } from '../context/AuthContext';
import type { User } from '../types';

const emptyForm = {
  firstName: '',
  lastName: '',
  email: '',
  phone: '',
  role: 'USER',
  isActive: true,
  password: ''
};

const roles = ['USER', 'PROVIDER', 'ADMIN', 'MANAGER'];

const UsersPage = () => {
  const { token } = useAuth();
  const [items, setItems] = useState<User[]>([]);
  const [form, setForm] = useState({ ...emptyForm });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const load = async () => {
    if (!token) return;
    setLoading(true);
    setError('');
    try {
      const data = await adminListUsers(token);
      setItems(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load users');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, [token]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setError('');
    setSuccess('');
    if (!form.firstName.trim() || !form.lastName.trim() || !form.email.trim() || !form.phone.trim()) {
      setError('First name, last name, email, and phone are required.');
      return;
    }
    if (!editingId && !form.password.trim()) {
      setError('Password is required for new users.');
      return;
    }
    setLoading(true);
    try {
      const payload: Partial<User> & { password?: string } = {
        firstName: form.firstName.trim(),
        lastName: form.lastName.trim(),
        email: form.email.trim(),
        phone: form.phone.trim(),
        role: form.role,
        isActive: form.isActive
      };
      if (form.password.trim()) {
        payload.password = form.password.trim();
      }
      if (editingId) {
        await adminUpdateUser(token, editingId, payload);
        setSuccess('User updated.');
      } else {
        if (!payload.password) throw new Error('Password missing');
        await adminCreateUser(token, payload as Required<typeof payload>);
        setSuccess('User created.');
      }
      setForm({ ...emptyForm });
      setEditingId(null);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Save failed');
    } finally {
      setLoading(false);
    }
  };

  const startEdit = (user: User) => {
    setEditingId(user._id);
    setForm({
      firstName: user.firstName || '',
      lastName: user.lastName || '',
      email: user.email || '',
      phone: user.phone || '',
      role: user.role || 'USER',
      isActive: user.isActive !== false,
      password: ''
    });
  };

  const handleDelete = async (id: string) => {
    if (!token) return;
    if (!window.confirm('Deactivate this user?')) return;
    setError('');
    setSuccess('');
    try {
      await adminDeleteUser(token, id);
      setSuccess('User deactivated.');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Delete failed');
    }
  };

  return (
    <div>
      <div className="panel">
        <div className="section-title">
          <h2>{editingId ? 'Edit user' : 'Create user'}</h2>
          <small>Admin can manage any account</small>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="form-row">
            <div>
              <label htmlFor="firstName">First name</label>
              <input
                id="firstName"
                value={form.firstName}
                onChange={(e) => setForm((prev) => ({ ...prev, firstName: e.target.value }))}
                required
              />
            </div>
            <div>
              <label htmlFor="lastName">Last name</label>
              <input
                id="lastName"
                value={form.lastName}
                onChange={(e) => setForm((prev) => ({ ...prev, lastName: e.target.value }))}
                required
              />
            </div>
            <div>
              <label htmlFor="email">Email</label>
              <input
                id="email"
                type="email"
                value={form.email}
                onChange={(e) => setForm((prev) => ({ ...prev, email: e.target.value }))}
                required
              />
            </div>
            <div>
              <label htmlFor="phone">Phone</label>
              <input
                id="phone"
                value={form.phone}
                onChange={(e) => setForm((prev) => ({ ...prev, phone: e.target.value }))}
                required
              />
            </div>
            <div>
              <label htmlFor="role">Role</label>
              <select
                id="role"
                value={form.role}
                onChange={(e) => setForm((prev) => ({ ...prev, role: e.target.value }))}
              >
                {roles.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="isActive">Status</label>
              <select
                id="isActive"
                value={form.isActive ? 'true' : 'false'}
                onChange={(e) => setForm((prev) => ({ ...prev, isActive: e.target.value === 'true' }))}
              >
                <option value="true">Active</option>
                <option value="false">Inactive</option>
              </select>
            </div>
            <div>
              <label htmlFor="password">{editingId ? 'Password (optional)' : 'Password'}</label>
              <input
                id="password"
                type="password"
                value={form.password}
                onChange={(e) => setForm((prev) => ({ ...prev, password: e.target.value }))}
                placeholder={editingId ? 'Leave blank to keep current' : ''}
              />
            </div>
          </div>
          {error ? <div className="error">{error}</div> : null}
          {success ? <div className="success">{success}</div> : null}
          <div style={{ display: 'flex', gap: 12, marginTop: 12 }}>
            <button className="btn" type="submit" disabled={loading}>
              {editingId ? 'Update user' : 'Create user'}
            </button>
            {editingId ? (
              <button
                type="button"
                className="btn secondary"
                onClick={() => {
                  setForm({ ...emptyForm });
                  setEditingId(null);
                }}
              >
                Cancel edit
              </button>
            ) : null}
          </div>
        </form>
      </div>

      <div className="panel">
        <div className="section-title">
          <h2>All users</h2>
          <small>{items.length} records</small>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Role</th>
                <th>Status</th>
                <th style={{ width: 160 }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.length ? (
                items.map((u) => (
                  <tr key={u._id}>
                    <td>
                      {u.firstName} {u.lastName}
                    </td>
                    <td>{u.email}</td>
                    <td>{u.phone}</td>
                    <td>{u.role}</td>
                    <td>
                      <span className={`status-pill status-${u.isActive ? 'APPROVED' : 'REJECTED'}`}>
                        {u.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: 8 }}>
                        <button className="btn secondary" onClick={() => startEdit(u)}>
                          Edit
                        </button>
                        <button className="btn danger" onClick={() => void handleDelete(u._id)}>
                          Deactivate
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6}>No users found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {loading ? <div className="helper">Loading...</div> : null}
    </div>
  );
};

export default UsersPage;
