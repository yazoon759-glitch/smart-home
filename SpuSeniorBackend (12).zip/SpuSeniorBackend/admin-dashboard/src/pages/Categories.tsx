import { type FormEvent, useEffect, useState } from 'react';
import {
  createCategory,
  deleteCategory,
  listCategories,
  updateCategory
} from '../api/admin';
import { useAuth } from '../context/AuthContext';
import type { Category } from '../types';

type CategoryForm = {
  name: string;
  description: string;
  basePrice: string;
  icon: string;
  isActive: boolean;
};

const emptyForm: CategoryForm = {
  name: '',
  description: '',
  basePrice: '',
  icon: '',
  isActive: true
};

const CategoriesPage = () => {
  const { token } = useAuth();
  const [items, setItems] = useState<Category[]>([]);
  const [form, setForm] = useState<CategoryForm>(emptyForm);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const load = async () => {
    if (!token) return;
    setLoading(true);
    setError('');
    try {
      const data = await listCategories(token);
      setItems(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load categories');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, [token]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setError('');
    setSuccess('');
    setLoading(true);
    try {
      const payload = {
        name: form.name.trim(),
        description: form.description.trim(),
        icon: form.icon.trim() || null,
        basePrice: Number(form.basePrice),
        isActive: form.isActive
      };
      if (!payload.name || Number.isNaN(payload.basePrice)) {
        throw new Error('Name and base price are required.');
      }
      if (editingId) {
        await updateCategory(token, editingId, payload);
        setSuccess('Category updated.');
      } else {
        await createCategory(token, payload);
        setSuccess('Category created.');
      }
      setForm(emptyForm);
      setEditingId(null);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Save failed');
    } finally {
      setLoading(false);
    }
  };

  const startEdit = (cat: Category) => {
    setEditingId(cat._id);
    setForm({
      name: cat.name,
      description: cat.description || '',
      basePrice: String(cat.basePrice),
      icon: cat.icon || '',
      isActive: cat.isActive
    });
  };

  const handleDelete = async (id: string) => {
    if (!token) return;
    if (!window.confirm('Delete this category?')) return;
    setError('');
    setSuccess('');
    try {
      await deleteCategory(token, id);
      setSuccess('Category removed.');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Delete failed');
    }
  };

  return (
    <div>
      <div className="panel">
        <div className="section-title">
          <h2>{editingId ? 'Edit category' : 'Create category'}</h2>
          <small>Manage the services you offer</small>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="form-row">
            <div>
              <label htmlFor="name">Name</label>
              <input
                id="name"
                name="name"
                required
                value={form.name}
                onChange={(e) => setForm((prev) => ({ ...prev, name: e.target.value }))}
              />
            </div>
            <div>
              <label htmlFor="basePrice">Base price</label>
              <input
                id="basePrice"
                name="basePrice"
                required
                type="number"
                min="0"
                value={form.basePrice}
                onChange={(e) => setForm((prev) => ({ ...prev, basePrice: e.target.value }))}
              />
            </div>
            <div>
              <label htmlFor="icon">Icon URL (optional)</label>
              <input
                id="icon"
                name="icon"
                value={form.icon}
                onChange={(e) => setForm((prev) => ({ ...prev, icon: e.target.value }))}
              />
            </div>
            <div>
              <label htmlFor="isActive">Status</label>
              <select
                id="isActive"
                value={form.isActive ? 'true' : 'false'}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, isActive: e.target.value === 'true' }))
                }
              >
                <option value="true">Active</option>
                <option value="false">Hidden</option>
              </select>
            </div>
          </div>
          <div style={{ marginTop: 12 }}>
            <label htmlFor="description">Description</label>
            <textarea
              id="description"
              rows={3}
              value={form.description}
              onChange={(e) => setForm((prev) => ({ ...prev, description: e.target.value }))}
            />
          </div>
          {error ? <div className="error">{error}</div> : null}
          {success ? <div className="success">{success}</div> : null}
          <div style={{ display: 'flex', gap: 12, marginTop: 12 }}>
            <button className="btn" type="submit" disabled={loading}>
              {editingId ? 'Update category' : 'Add category'}
            </button>
            {editingId ? (
              <button
                type="button"
                className="btn secondary"
                onClick={() => {
                  setForm(emptyForm);
                  setEditingId(null);
                }}
              >
                Cancel edit
              </button>
            ) : null}
          </div>
        </form>
      </div>

      <div className="panel">
        <div className="section-title">
          <h2>All categories</h2>
          <small>{items.length} items</small>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Price</th>
                <th>Status</th>
                <th>Description</th>
                <th style={{ width: 150 }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.length ? (
                items.map((cat) => (
                  <tr key={cat._id}>
                    <td>{cat.name}</td>
                    <td>${cat.basePrice.toFixed(2)}</td>
                    <td>
                      <span className={`status-pill status-${cat.isActive ? 'APPROVED' : 'REJECTED'}`}>
                        {cat.isActive ? 'Active' : 'Hidden'}
                      </span>
                    </td>
                    <td style={{ maxWidth: 260 }}>{cat.description || '—'}</td>
                    <td>
                      <div style={{ display: 'flex', gap: 8 }}>
                        <button className="btn secondary" onClick={() => startEdit(cat)}>
                          Edit
                        </button>
                        <button className="btn danger" onClick={() => handleDelete(cat._id)}>
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5}>No categories yet.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {loading ? <div className="helper">Working…</div> : null}
    </div>
  );
};

export default CategoriesPage;
